#include <unistd.h>

void	ft_write1234(x, y, *tablafija)
{
	if ( y = 1)
	{	
		counter = 0;
		while(counter <= 3)
		{
			tablafija(y, (x - 1) + counter = counter + 1;
			counter++;
			return (0);
		}
	}	
	if (y = 2)
	{
		counter = 0;
		while(counter <= 3);
		{
			tablafija(y, (x + 1) - counter = counter + 1;
			counter++;
			return(0);
		}
	}
	if ( y = 0)
	{	
		counter = 0;
		while(counter <= 3)
		{
			tablafija(x, (y + 1) + counter = counter + 1;
			counter++;
			return (0);
		}
	}
	if ( y = 3)
	{	
		counter = 0;
		while(counter <= 3)
		{
			tablafija(x, (y - 1) - counter = counter + 1;
			counter++;
			return (0);
		}
	}
}

